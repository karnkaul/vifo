# Basic Downloader (using libcurl)

[![Build status](https://github.com/karnkaul/kcurl/actions/workflows/ci.yml/badge.svg)](https://github.com/karnkaul/kcurl/actions/workflows/ci.yml)

`kcurl` is a simple wrapper over libcurl, specifically performing requests through easy handles.

## Usage

- Only build-from-source workflows are supported
- Use CMake and a preset / generator of your choice
  - Set `KCURL_LIBCURL_LINK_TARGET` to the name of a custom CMake target that provides libcurl, if applicable
    - Otherwise `kcurl` will use its own vendored libcurl source
- Link to the `kcurl::kcurl` CMake target
- Use the top-level `kcurl::Curl` RAII wrapper unless libcurl is already initialized/shut-down elsewhere
- TLS/SSL support depends on libcurl defaults for the build environment and/or user customization

### Example

See the included [example](example/src/main.cpp).

### API Reference

Hosted [here](https://karnkaul.github.io/kcurl/).

### Requirements

- Desktop OS (`int main()` entrypoint)
- CMake 3.24+
- C++23 compiler (and stdlib)

## Contributing

Pull requests are welcome.

[**Original Repository**](https://github.com/karnkaul/kcurl)
